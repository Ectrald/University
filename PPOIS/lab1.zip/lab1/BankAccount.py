# состояния: действующий(если баланс больше нуля), замороженный(если баланс меньше нуля)
import random
class BankAccount:
    #states = ['active', 'frozen']
    def __init__(self, balance):
        self.status = 'active'
        self._id = random.randint(10000000, 99999999)
        self._balance = balance

    def add_money(self, money):
        self._balance += money
        if self._balance > 0:
            self.status = 'active'
    def withdraw_money(self, money):
        if self.status == 'active':
            self._balance -= money
        else:
            print("Your bank account is frozen. Pay off the debt for activation")
            print(f"Your balance now: {self._balance}")
        if self._balance < 0:
            self.status = 'frozen'
    def print(self):
        print(f"id: {self._id}")
        print(f"status: {self.status}")
        print(f"balance: {self._balance}")

