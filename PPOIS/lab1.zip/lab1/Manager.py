# здесь будут операции снятие и внесение денег(работа с классом bankaccount)
# операция по инвестированию(работа с классом инвестмент) управление портфелем так же здесь(просмотр и продажа акций)
# операция формирования бюджета так же тут
# ну и фин отчеты тоже будут тут

from BankAccount import *
from Budget import *
from Investment import *
from Report import *
class Manager:
    def __init__(self):
        self.list_of_investments = []
        self.list_of_bank_accounts = []
        self.budget = Budget.Budget()
        self.list_of_reports = []
