
class Transaction:
    def __init__(self, status: str, amount, description):
        self.status = status
        self.amount = amount
        self.description = description
    def print(self):
        print(f"Status: {self.status}")
        print(f"Amount: {self.amount}")
        print(f"Description: {self.description}")

