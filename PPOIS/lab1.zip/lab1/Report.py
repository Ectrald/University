import Budget
class Report:
    def __init__(self, budget: Budget):
        self.budget = budget

    def generate_income_report(self):
        report = f"--- Income Report ---\n"
        report += f"Total Income: {self.budget.income}\n"
        report += "Transactions:\n"
        for transaction in self.budget.transactions:
            if transaction.status == 'income':
                report += f"- {transaction.description}: {transaction.amount}\n"
        return report

    def generate_expense_report(self):
        report = f"--- Expense Report ---\n"
        report += f"Total Expenses: {self.budget.expenses}\n"
        report += "Transactions:\n"
        for transaction in self.budget.transactions:
            if transaction.status == 'expense':
                report += f"- {transaction.description}: {transaction.amount}\n"
        return report

    def generate_net_profit_report(self):
        net_profit = self.budget.income - self.budget.expenses
        report = f"--- Net Profit Report ---\n"
        report += f"Net Profit: {net_profit}\n"
        return report

    def print_report(self):
        print(self.generate_income_report())
        print(self.generate_expense_report())
        print(self.generate_net_profit_report())