# состояния: акции, криптовалюта, ценные металлы
class Investment:
    def __init__(self, type_of_investment: str, description: str, number_of_units_invested: float, unit_price: float):
        self.type_of_investment = type_of_investment
        self.unit_price = unit_price
        self.number_of_units_invested = number_of_units_invested
        self.description = description
