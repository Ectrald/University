# включает в себя поля дохода, расхода и тд и тп
# так же может включать в себя выбор времени плана(один месяц, год или 5 лет)
# здесь будет операция анализа расходов и доходов, график будет показывать отношение дохода к расходу
from Transaction import Transaction
class Budget:
    def __init__(self):
        self.expenses = 0.0
        self.income = 0.0
        self.transactions = []

    def add_income(self, amount: float, description: str = ""):
        if amount < 0:
            raise ValueError("Сумма дохода должна быть положительной.")
        self.income += amount
        self.transactions.append(Transaction('income', amount, description))
    def add_expense(self, amount: float, description: str = ""):
        if amount < 0:
            raise ValueError("Сумма расхода должна быть положительной.")
        self.expenses += amount
        self.transactions.append(Transaction('expense', amount, description))
    def analyze(self):
        net_profit = self.income - self.expenses
        print(f"Net profit is {net_profit}")
    def print(self):
        print(f"Income: {self.income}")
        print(f"Expenses: {self.expenses}")
        for transaction in self.transactions:
            transaction.print()

