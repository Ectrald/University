"""
Модель мониторинга финансов 81

Предметная область: отслеживание и анализ финансовых операций.

Важные сущности: банковские счета, транзакции, бюджет, инвестиции, отчеты.

Операции: операция внесения и снятия денег,
операция анализа расходов и доходов,
операция инвестирования и управления портфелем,
операция формирования бюджета,
операция генерации финансовых отчетов.
"""
from Manager import *


def main():
    manager = Manager()
    while True:
        print("\nФинансовый мониторинг")
        print("1. Управление банковскими счетами")
        print("2. Управление бюджетом")
        print("3. Управление инвестициями")
        print("4. Генерация отчетов")
        print("5. Выход")
        choice = input("Выберите действие: ")

        if choice == "1":
            manage_bank_accounts(manager)
        elif choice == "2":
            manage_budget(manager)
        elif choice == "3":
            manage_investments(manager)
        elif choice == "4":
            generate_reports(manager)
        elif choice == "5":
            break
        else:
            print("Неверный ввод. Попробуйте снова.")


def get_float_input(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Ошибка: Введите числовое значение.")


def get_int_input(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            print("Ошибка: Введите целое число.")


def choose_bank_account(manager):
    if not manager.list_of_bank_accounts:
        print("Нет доступных счетов.")
        return None
    print("\nСписок доступных счетов:")
    for i, acc in enumerate(manager.list_of_bank_accounts, start=1):
        print(f"{i}. ID: {acc._id}, Баланс: {acc._balance}")
    choice = get_int_input("Выберите номер счета (0 для выхода): ")
    if choice == 0:
        return None
    if 1 <= choice <= len(manager.list_of_bank_accounts):
        return manager.list_of_bank_accounts[choice - 1]
    print("Неверный выбор.")
    return None


def manage_bank_accounts(manager):
    while True:
        print("\nУправление банковскими счетами")
        print("1. Добавить счет")
        print("2. Пополнить счет")
        print("3. Снять деньги")
        print("4. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":
            balance = get_float_input("Введите начальный баланс: ")
            account = BankAccount(balance)
            manager.list_of_bank_accounts.append(account)
            print("Счет добавлен.")
        elif choice == "2":
            account = choose_bank_account(manager)
            if account:
                amount = get_float_input("Введите сумму: ")
                account.add_money(amount)
                manager.budget.add_income(amount, "Пополнение счета")
                print("Баланс пополнен и записан в бюджет.")
        elif choice == "3":
            account = choose_bank_account(manager)
            if account:
                amount = get_float_input("Введите сумму: ")
                account.withdraw_money(amount)
                manager.budget.add_expense(amount, "Снятие денег со счета")
                print("Деньги сняты и записаны в бюджет.")
        elif choice == "4":
            break


def manage_budget(manager):
    while True:
        print("\nУправление бюджетом")
        print("1. Добавить доход")
        print("2. Добавить расход")
        print("3. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":
            amount = get_float_input("Введите сумму дохода: ")
            description = input("Введите описание: ")
            manager.budget.add_income(amount, description)
            print("Доход добавлен.")
        elif choice == "2":
            amount = get_float_input("Введите сумму расхода: ")
            description = input("Введите описание: ")
            manager.budget.add_expense(amount, description)
            print("Расход добавлен.")
        elif choice == "3":
            break


def manage_investments(manager):
    while True:
        print("\nУправление инвестициями")
        print("1. Добавить инвестицию")
        print("2. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":
            type_of_investment = input("Введите тип инвестиции: ")
            description = input("Введите описание: ")
            number_of_units = get_float_input("Введите количество единиц: ")
            unit_price = get_float_input("Введите цену за единицу: ")
            account = choose_bank_account(manager)
            if account:
                total_cost = number_of_units * unit_price
                if account._balance >= total_cost:
                    account.withdraw_money(total_cost)
                    manager.budget.add_expense(total_cost, "Инвестиция")
                    investment = Investment(type_of_investment, description, number_of_units, unit_price)
                    manager.list_of_investments.append(investment)
                    print("Инвестиция добавлена и записана в бюджет.")
                else:
                    print("Недостаточно средств на выбранном счете.")
        elif choice == "2":
            break


def generate_reports(manager):
    print("\nФинансовые отчёты")
    report = Report(manager.budget)
    print(report.generate_income_report())
    print(report.generate_expense_report())
    print(report.generate_net_profit_report())


if __name__ == "__main__":
    main()
