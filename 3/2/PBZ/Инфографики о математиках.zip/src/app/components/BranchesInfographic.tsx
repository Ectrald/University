import { Network, Calculator, Sigma, Infinity, Shapes, Binary } from 'lucide-react';

interface Branch {
  icon: React.ReactNode;
  name: string;
  description: string;
  examples: string;
  color: string;
  rotation: string;
}

export function BranchesInfographic() {
  const branches: Branch[] = [
    {
      icon: <Calculator className="w-8 h-8" />,
      name: "Арифметика",
      description: "Наука о числах и основных операциях с ними",
      examples: "Сложение, вычитание, умножение, деление",
      color: "bg-rose-500",
      rotation: "rotate-2"
    },
    {
      icon: <Shapes className="w-8 h-8" />,
      name: "Геометрия",
      description: "Изучение форм, размеров и свойств пространства",
      examples: "Треугольники, окружности, теорема Пифагора",
      color: "bg-blue-500",
      rotation: "-rotate-1"
    },
    {
      icon: <Sigma className="w-8 h-8" />,
      name: "Алгебра",
      description: "Работа с символами и правилами их преобразования",
      examples: "Уравнения, функции, многочлены",
      color: "bg-purple-500",
      rotation: "rotate-1"
    },
    {
      icon: <Infinity className="w-8 h-8" />,
      name: "Мат. анализ",
      description: "Изучение пределов, производных и интегралов",
      examples: "Дифференцирование, интегрирование",
      color: "bg-green-500",
      rotation: "-rotate-2"
    },
    {
      icon: <Binary className="w-8 h-8" />,
      name: "Дискретная математика",
      description: "Математика конечных или счетных структур",
      examples: "Комбинаторика, теория графов, логика",
      color: "bg-orange-500",
      rotation: "rotate-1"
    },
    {
      icon: <Network className="w-8 h-8" />,
      name: "Теория вероятностей",
      description: "Изучение случайных явлений и событий",
      examples: "Статистика, случайные величины",
      color: "bg-teal-500",
      rotation: "-rotate-1"
    }
  ];

  return (
    <div className="relative bg-gradient-to-br from-amber-50 to-orange-50 rounded-3xl shadow-2xl p-12 overflow-hidden">
      {/* Background texture */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1615800098746-73af8261e3df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlfGVufDF8fHx8MTc3MjgxNDA4OXww&ixlib=rb-4.1.0&q=80&w=1080" 
          alt="texture" 
          className="w-full h-full object-cover opacity-20"
        />
      </div>

      {/* Decorative mathematical symbols */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div className="absolute top-20 left-20 text-7xl">∑</div>
        <div className="absolute top-40 right-32 text-6xl">∫</div>
        <div className="absolute bottom-32 left-32 text-7xl">√</div>
        <div className="absolute bottom-20 right-20 text-6xl">∞</div>
        <div className="absolute top-1/2 left-1/4 text-5xl">π</div>
      </div>

      {/* Header */}
      <div className="relative z-10 mb-12">
        <div className="inline-block bg-white px-10 py-6 rounded-2xl shadow-xl border-4 border-amber-300 rotate-1">
          <h1 className="text-6xl text-amber-900 mb-2">РАЗДЕЛЫ</h1>
          <h2 className="text-4xl text-amber-700">Математики</h2>
          <div className="mt-3 pt-3 border-t-2 border-amber-300">
            <p className="text-amber-600">Основные направления науки о числах</p>
          </div>
        </div>
      </div>

      {/* Branches Grid */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {branches.map((branch, index) => (
          <div key={index} className={`group ${branch.rotation} hover:rotate-0 transition-all duration-300`}>
            <div className="relative bg-white rounded-2xl shadow-lg overflow-hidden border-4 border-amber-200 h-full">
              {/* Colored header */}
              <div className={`${branch.color} p-6 text-white relative overflow-hidden`}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                <div className="relative z-10 flex items-center gap-3 mb-2">
                  {branch.icon}
                  <h3 className="text-2xl">{branch.name}</h3>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-gray-700 mb-4 leading-relaxed">
                  {branch.description}
                </p>
                <div className="bg-amber-50 rounded-lg p-4 border-2 border-amber-200">
                  <p className="text-sm text-amber-900">
                    <span className="block mb-1 text-amber-600">Примеры:</span>
                    {branch.examples}
                  </p>
                </div>
              </div>

              {/* Decorative corner */}
              <div className="absolute top-4 right-4">
                <div className="w-12 h-12 border-2 border-white/50 rounded-lg rotate-45"></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Decorative vintage stamp */}
      <div className="absolute bottom-12 right-12 z-20">
        <div className="relative">
          <div className="w-32 h-32 border-8 border-amber-700 rounded-full flex items-center justify-center rotate-12 bg-white/90 shadow-xl">
            <div className="text-center">
              <div className="text-4xl text-amber-700 mb-1">∞</div>
              <div className="text-xs text-amber-600">МАТЕМАТИКА</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
