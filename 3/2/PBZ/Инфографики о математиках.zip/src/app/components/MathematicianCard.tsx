import { Brain, Award, BookOpen } from 'lucide-react';

interface MathematicianCardProps {
  name: string;
  years: string;
  nationality: string;
  imageUrl: string;
  mainContribution: string;
  famousWork: string;
  funFact: string;
  accentColor: string;
  bgGradient: string;
}

export function MathematicianCard({
  name,
  years,
  nationality,
  imageUrl,
  mainContribution,
  famousWork,
  funFact,
  accentColor,
  bgGradient,
}: MathematicianCardProps) {
  return (
    <div className={`relative overflow-hidden rounded-3xl shadow-2xl ${bgGradient} p-8`}>
      {/* Decorative circles */}
      <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white/10 blur-3xl -translate-y-32 translate-x-32"></div>
      <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-white/10 blur-2xl translate-y-24 -translate-x-24"></div>
      
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-start gap-6 mb-8">
          <div className="w-32 h-32 rounded-2xl overflow-hidden shadow-xl ring-4 ring-white/30 flex-shrink-0">
            <img 
              src={imageUrl} 
              alt={name}
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="flex-1">
            <h2 className="text-4xl text-white mb-2 tracking-tight">{name}</h2>
            <div className="text-white/90 text-lg mb-1">{years}</div>
            <div className={`inline-block px-4 py-1 rounded-full ${accentColor} text-white text-sm`}>
              {nationality}
            </div>
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid gap-4">
          {/* Main Contribution */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-3">
              <div className={`p-2 rounded-lg ${accentColor}`}>
                <Brain className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-gray-900">Основной вклад</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">{mainContribution}</p>
          </div>

          {/* Famous Work */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-3">
              <div className={`p-2 rounded-lg ${accentColor}`}>
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-gray-900">Известные работы</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">{famousWork}</p>
          </div>

          {/* Fun Fact */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-3">
              <div className={`p-2 rounded-lg ${accentColor}`}>
                <Award className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl text-gray-900">Интересный факт</h3>
            </div>
            <p className="text-gray-700 leading-relaxed">{funFact}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
