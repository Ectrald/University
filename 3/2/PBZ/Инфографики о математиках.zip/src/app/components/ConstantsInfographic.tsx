import { Sparkles } from 'lucide-react';

interface MathConstant {
  symbol: string;
  name: string;
  value: string;
  description: string;
  usage: string;
  color: string;
  bgColor: string;
  image: string;
}

export function ConstantsInfographic() {
  const constants: MathConstant[] = [
    {
      symbol: "π",
      name: "Число Пи",
      value: "3.14159265...",
      description: "Отношение длины окружности к её диаметру",
      usage: "Геометрия, тригонометрия, физика волн",
      color: "text-blue-700",
      bgColor: "bg-blue-100",
      image: "https://images.unsplash.com/photo-1762141018794-17f5186d1180?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyeSUyMGNvbXBhc3MlMjB0b29sc3xlbnwxfHx8fDE3NzI4MTk3MDd8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      symbol: "e",
      name: "Число Эйлера",
      value: "2.71828182...",
      description: "Основание натурального логарифма",
      usage: "Экспоненциальный рост, сложные проценты",
      color: "text-purple-700",
      bgColor: "bg-purple-100",
      image: "https://images.unsplash.com/photo-1758685733685-7e0f30c35a17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRoZW1hdGljYWwlMjBzeW1ib2xzJTIwYmxhY2tib2FyZHxlbnwxfHx8fDE3NzI4MTk3MDd8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      symbol: "φ",
      name: "Золотое сечение",
      value: "1.61803398...",
      description: "Божественная пропорция в природе и искусстве",
      usage: "Архитектура, дизайн, последовательность Фибоначчи",
      color: "text-amber-700",
      bgColor: "bg-amber-100",
      image: "https://images.unsplash.com/photo-1631410260318-60e3c97895a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbnRpcXVlJTIwYm9vayUyMHBhZ2VzfGVufDF8fHx8MTc3MjgxOTcwN3ww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      symbol: "i",
      name: "Мнимая единица",
      value: "√-1",
      description: "Квадратный корень из минус единицы",
      usage: "Комплексные числа, электротехника, квантовая механика",
      color: "text-emerald-700",
      bgColor: "bg-emerald-100",
      image: "https://images.unsplash.com/photo-1764509195129-1ea255a907b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGQlMjBtYW51c2NyaXB0JTIwcGFyY2htZW50fGVufDF8fHx8MTc3MjgxOTcwN3ww&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  return (
    <div className="relative bg-[#faf8f3] rounded-3xl shadow-2xl p-12 overflow-hidden">
      {/* Background vintage texture */}
      <div className="absolute inset-0 opacity-30">
        <img 
          src="https://images.unsplash.com/photo-1615800098746-73af8261e3df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlfGVufDF8fHx8MTc3MjgxNDA4OXww&ixlib=rb-4.1.0&q=80&w=1080" 
          alt="texture" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-8 right-12 w-24 h-32 border-8 border-red-400 opacity-20 -rotate-12"></div>
      <div className="absolute bottom-12 left-8 w-32 h-24 border-8 border-blue-400 opacity-20 rotate-6"></div>
      
      {/* Vintage postal marks */}
      <div className="absolute top-16 left-16">
        <div className="flex gap-1">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="w-3 h-8 bg-gray-400/30"></div>
          ))}
        </div>
      </div>

      {/* Header */}
      <div className="relative z-10 mb-12">
        <div className="inline-block">
          <div className="bg-white px-12 py-8 rounded-2xl shadow-2xl border-8 border-double border-gray-300 -rotate-1">
            <div className="flex items-center gap-4 mb-3">
              <Sparkles className="w-10 h-10 text-gray-700" />
              <div>
                <p className="text-lg text-gray-600 tracking-widest">ЗНАМЕНИТЫЕ</p>
                <h1 className="text-6xl text-gray-900 tracking-tight">Константы</h1>
              </div>
            </div>
            <div className="border-t-4 border-dashed border-gray-300 pt-3 mt-3">
              <p className="text-gray-600">Фундаментальные числа математики</p>
            </div>
          </div>
        </div>
      </div>

      {/* Constants Cards */}
      <div className="relative z-10 space-y-8">
        {constants.map((constant, index) => (
          <div 
            key={index} 
            className={`flex items-stretch gap-6 ${index % 2 === 0 ? '' : 'flex-row-reverse'}`}
          >
            {/* Image with vintage frame */}
            <div className={`w-1/3 ${index % 2 === 0 ? 'rotate-2' : '-rotate-2'} hover:rotate-0 transition-transform`}>
              <div className="relative">
                <div className="absolute inset-0 bg-gray-800 translate-x-2 translate-y-2"></div>
                <div className="relative border-8 border-white shadow-2xl overflow-hidden">
                  <img 
                    src={constant.image} 
                    alt={constant.name}
                    className="w-full h-64 object-cover"
                  />
                  {/* Vintage tape effect */}
                  <div className="absolute top-4 -left-2 w-16 h-8 bg-amber-200/80 -rotate-45"></div>
                  <div className="absolute bottom-4 -right-2 w-16 h-8 bg-amber-200/80 rotate-45"></div>
                </div>
              </div>
            </div>

            {/* Content card */}
            <div className="flex-1">
              <div className={`bg-white rounded-2xl shadow-xl border-4 border-gray-200 overflow-hidden h-full ${index % 2 === 0 ? '-rotate-1' : 'rotate-1'} hover:rotate-0 transition-transform`}>
                {/* Header with symbol */}
                <div className={`${constant.bgColor} px-6 py-4 border-b-4 border-dashed border-gray-300`}>
                  <div className="flex items-center gap-4">
                    <div className={`text-7xl ${constant.color}`}>{constant.symbol}</div>
                    <div>
                      <h3 className="text-3xl text-gray-900">{constant.name}</h3>
                      <p className={`text-xl ${constant.color} font-mono`}>{constant.value}</p>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div>
                    <div className="inline-block bg-gray-800 text-white px-3 py-1 text-xs tracking-wider mb-2">
                      ОПИСАНИЕ
                    </div>
                    <p className="text-gray-700 leading-relaxed">{constant.description}</p>
                  </div>

                  <div>
                    <div className="inline-block bg-gray-800 text-white px-3 py-1 text-xs tracking-wider mb-2">
                      ПРИМЕНЕНИЕ
                    </div>
                    <p className="text-gray-600 text-sm leading-relaxed">{constant.usage}</p>
                  </div>
                </div>

                {/* Decorative corner stamp */}
                <div className="absolute top-4 right-4">
                  <div className={`w-16 h-16 ${constant.bgColor} rounded-full flex items-center justify-center rotate-12 border-4 border-white shadow-lg`}>
                    <span className={`text-2xl ${constant.color}`}>{constant.symbol}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom decorative stamp */}
      <div className="absolute bottom-8 right-16 z-20">
        <div className="relative rotate-12">
          <div className="border-4 border-red-600 rounded-lg p-4 bg-white/90">
            <div className="text-center">
              <div className="text-xs text-red-600 mb-1 tracking-wider">CLASSIFIED</div>
              <div className="text-2xl text-red-600">∞</div>
              <div className="text-xs text-red-600 mt-1">MATHEMATICS</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
