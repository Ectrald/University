import { Calendar } from 'lucide-react';

interface TimelineEvent {
  period: string;
  title: string;
  description: string;
  image: string;
  position: 'left' | 'right';
}

export function TimelineInfographic() {
  const events: TimelineEvent[] = [
    {
      period: "3000 до н.э. - 500 н.э.",
      title: "Древний мир",
      description: "Вавилоняне и египтяне разработали базовую арифметику и геометрию. Греческие математики (Пифагор, Евклид) создали основы логических доказательств.",
      image: "https://images.unsplash.com/photo-1764509195129-1ea255a907b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbGQlMjBtYW51c2NyaXB0JTIwcGFyY2htZW50fGVufDF8fHx8MTc3MjgxOTcwN3ww&ixlib=rb-4.1.0&q=80&w=1080",
      position: "left"
    },
    {
      period: "500 - 1400",
      title: "Средние века",
      description: "Индийские и арабские математики ввели десятичную систему счисления и алгебру. Появление нуля как числа.",
      image: "https://images.unsplash.com/photo-1631410260318-60e3c97895a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbnRpcXVlJTIwYm9vayUyMHBhZ2VzfGVufDF8fHx8MTc3MjgxOTcwN3ww&ixlib=rb-4.1.0&q=80&w=1080",
      position: "right"
    },
    {
      period: "1600 - 1800",
      title: "Эпоха Просвещения",
      description: "Создание математического анализа Ньютоном и Лейбницем. Развитие теории вероятностей и аналитической геометрии.",
      image: "https://images.unsplash.com/photo-1762141018794-17f5186d1180?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyeSUyMGNvbXBhc3MlMjB0b29sc3xlbnwxfHx8fDE3NzI4MTk3MDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      position: "left"
    },
    {
      period: "1800 - 1900",
      title: "XIX век",
      description: "Бурное развитие абстрактной алгебры, неевклидовой геометрии, теории множеств и математической логики.",
      image: "https://images.unsplash.com/photo-1758685733685-7e0f30c35a17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRoZW1hdGljYWwlMjBzeW1ib2xzJTIwYmxhY2tib2FyZHxlbnwxfHx8fDE3NzI4MTk3MDd8MA&ixlib=rb-4.1.0&q=80&w=1080",
      position: "right"
    },
    {
      period: "1900 - настоящее время",
      title: "Современная эпоха",
      description: "Появление компьютеров революционизировало математику. Развитие теории хаоса, фракталов, криптографии и вычислительной математики.",
      image: "https://images.unsplash.com/photo-1615800098746-73af8261e3df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwcGFwZXIlMjB0ZXh0dXJlfGVufDF8fHx8MTc3MjgxNDA4OXww&ixlib=rb-4.1.0&q=80&w=1080",
      position: "left"
    }
  ];

  return (
    <div className="relative bg-[#f5f1e8] rounded-3xl shadow-2xl p-12 overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 right-10 text-9xl text-amber-900">∑</div>
        <div className="absolute bottom-10 left-10 text-9xl text-amber-900">∫</div>
      </div>

      {/* Header */}
      <div className="relative z-10 text-center mb-16">
        <div className="inline-block bg-white px-8 py-4 rounded-2xl shadow-lg border-4 border-amber-200 -rotate-1">
          <div className="flex items-center gap-3 justify-center mb-2">
            <Calendar className="w-8 h-8 text-amber-700" />
            <h2 className="text-5xl text-amber-900">ИСТОРИЯ</h2>
          </div>
          <h1 className="text-6xl text-amber-900 tracking-tight">Математики</h1>
          <p className="text-amber-700 mt-2">От древности до наших дней</p>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative z-10">
        {/* Vertical line */}
        <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-amber-400 -translate-x-1/2"></div>

        {events.map((event, index) => (
          <div key={index} className={`relative mb-16 flex items-center ${event.position === 'left' ? 'flex-row' : 'flex-row-reverse'}`}>
            {/* Content */}
            <div className={`w-5/12 ${event.position === 'left' ? 'text-right pr-12' : 'text-left pl-12'}`}>
              <div className={`inline-block bg-white p-6 rounded-xl shadow-lg border-2 border-amber-200 ${event.position === 'left' ? 'rotate-1' : '-rotate-1'} hover:rotate-0 transition-transform`}>
                <div className="mb-3">
                  <span className="inline-block bg-amber-600 text-white px-4 py-1 rounded-full text-sm mb-3">
                    {event.period}
                  </span>
                  <h3 className="text-2xl text-amber-900 mb-2">{event.title}</h3>
                </div>
                <p className="text-gray-700 text-sm leading-relaxed">{event.description}</p>
              </div>
            </div>

            {/* Center dot */}
            <div className="absolute left-1/2 -translate-x-1/2 w-6 h-6 bg-amber-600 rounded-full border-4 border-white shadow-lg z-10"></div>

            {/* Image */}
            <div className={`w-5/12 ${event.position === 'left' ? 'pl-12' : 'pr-12'}`}>
              <div className={`relative overflow-hidden rounded-lg shadow-xl ${event.position === 'left' ? '-rotate-2' : 'rotate-2'} hover:rotate-0 transition-transform`}>
                <img src={event.image} alt={event.title} className="w-full h-48 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Decorative stamps */}
      <div className="absolute top-8 left-8 w-20 h-20 border-4 border-amber-600 rounded-lg rotate-12 opacity-30 flex items-center justify-center">
        <span className="text-2xl">π</span>
      </div>
      <div className="absolute bottom-8 right-8 w-20 h-20 border-4 border-amber-600 rounded-lg -rotate-12 opacity-30 flex items-center justify-center">
        <span className="text-2xl">∞</span>
      </div>
    </div>
  );
}
