import { TimelineInfographic } from './components/TimelineInfographic';
import { BranchesInfographic } from './components/BranchesInfographic';
import { ConstantsInfographic } from './components/ConstantsInfographic';

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-100 via-amber-50 to-stone-100 py-16 px-8">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Main Title */}
        <div className="text-center mb-16">
          <div className="inline-block bg-white px-16 py-8 rounded-3xl shadow-2xl border-8 border-double border-amber-300 rotate-1">
            <h1 className="text-7xl text-amber-900 mb-3 tracking-tight">
              МИР МАТЕМАТИКИ
            </h1>
            <p className="text-2xl text-amber-700">
              Три увлекательные инфографики о науке чисел
            </p>
          </div>
        </div>

        {/* Infographic 1: История математики */}
        <TimelineInfographic />

        {/* Infographic 2: Разделы математики */}
        <BranchesInfographic />

        {/* Infographic 3: Математические константы */}
        <ConstantsInfographic />
      </div>
    </div>
  );
}